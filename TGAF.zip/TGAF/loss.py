#!/usr/bin/python
# -*- encoding: utf-8 -*-


import torch
import torch.nn as nn
import torch.nn.functional as F
import clip
import numpy as np

from torchvision import transforms
from PIL import Image


class Fusionloss(nn.Module):
    def __init__(self):
        super(Fusionloss, self).__init__()
        self.sobelconv = Sobelxy()
        self.pool = WavePool(1)

    def forward(self, image_vis, image_ir, generate_img):  # label
        image_y = image_vis[:, :1, :, :]
        x_in_max = torch.max(image_y, image_ir)
        loss_in = F.l1_loss(x_in_max, generate_img)
        y_grad = self.sobelconv(image_y)
        ir_grad = self.sobelconv(image_ir)
        generate_img_grad = self.sobelconv(generate_img)
        x_grad_joint = torch.max(y_grad, ir_grad)
        loss_grad = F.l1_loss(x_grad_joint, generate_img_grad)

        y_LL, y_LH, y_HL, y_HH = self.pool(image_y)
        ir_LL, ir_LH, ir_HL, ir_HH = self.pool(image_ir)
        f_LL, f_LH, f_HL, f_HH = self.pool(generate_img)

        x_LL_joint = torch.max(y_LL, ir_LL)
        x_LH_joint = torch.max(y_LH, ir_LH)
        x_HL_joint = torch.max(y_HL, ir_HL)
        x_HH_joint = torch.max(y_HH, ir_HH)

        loss_fre_LL = F.l1_loss(x_LL_joint, f_LL)
        loss_fre_LH = F.l1_loss(x_LH_joint, f_LH)
        loss_fre_HL = F.l1_loss(x_HL_joint, f_HL)
        loss_fre_HH = F.l1_loss(x_HH_joint, f_HH)
        loss_fre_total = loss_fre_LL + loss_fre_LH + loss_fre_HL + loss_fre_HH

        loss_total = 12 * loss_in + 15 * loss_grad + 15 * loss_fre_total
        return loss_total, loss_in, loss_grad, loss_fre_total


device = 'cuda' if torch.cuda.is_available() else 'cpu'
c_model, preprocess = clip.load("ViT-B/32", device=device)


class Fusionloss1(nn.Module):
    def __init__(self):
        super(Fusionloss1, self).__init__()
        self.sobelconv = Sobelxy()
        self.pool = WavePool(1)

    def forward(self, vi, ir, out):  # label
        # ir_3 = torch.cat([ir] * 3, dim=1)
        # vi_3 = torch.cat([vi] * 3, dim=1)
        # out_3 = torch.cat([out] * 3, dim=1)
        to_pil = transforms.ToPILImage()
        images_vi = [to_pil(vi[i].cpu()) for i in range(vi.shape[0])]
        images_ir = [to_pil(ir[i].cpu()) for i in range(ir.shape[0])]
        images_out = [to_pil(out[i].cpu()) for i in range(out.shape[0])]

        images_vis = torch.cat([preprocess(img).unsqueeze(0).to(device) for img in images_vi], dim=0)
        images_irs = torch.cat([preprocess(img).unsqueeze(0).to(device) for img in images_ir], dim=0)
        images_outs = torch.cat([preprocess(img).unsqueeze(0).to(device) for img in images_out], dim=0)

        vi_features = c_model.encode_image(images_vis)
        ir_features = c_model.encode_image(images_irs)
        out_features = c_model.encode_image(images_outs)
        text_description = "a vivid image with detailed background and obvious objects"
        text_input = torch.tensor(clip.tokenize(text_description)).to(device)
        text_feature = c_model.encode_text(text_input)
        loss_clip1 = torch.mean(torch.square(out_features - ir_features)) + torch.mean(
            torch.square(out_features - vi_features))
        # 计算相似度
        loss_clip2 = 1 - F.cosine_similarity(text_feature, out_features, dim=-1).mean()

        # loss_ssim = 10 * ssim_loss(out, ir, vi)
        # loss_gra = 100 * gra_loss(out, ir, vi)
        y_grad = self.sobelconv(vi)
        ir_grad = self.sobelconv(ir)
        generate_img_grad = self.sobelconv(out)
        x_grad_joint = torch.max(y_grad, ir_grad)
        loss_gra = F.l1_loss(x_grad_joint, generate_img_grad)

        y_LL, y_LH, y_HL, y_HH = self.pool(vi)
        ir_LL, ir_LH, ir_HL, ir_HH = self.pool(ir)
        f_LL, f_LH, f_HL, f_HH = self.pool(out)

        x_LL_joint = torch.max(y_LL, ir_LL)
        x_LH_joint = torch.max(y_LH, ir_LH)
        x_HL_joint = torch.max(y_HL, ir_HL)
        x_HH_joint = torch.max(y_HH, ir_HH)

        loss_fre_LL = F.l1_loss(x_LL_joint, f_LL)
        loss_fre_LH = F.l1_loss(x_LH_joint, f_LH)
        loss_fre_HL = F.l1_loss(x_HL_joint, f_HL)
        loss_fre_HH = F.l1_loss(x_HH_joint, f_HH)
        loss_fre_total = loss_fre_LL + loss_fre_LH + loss_fre_HL + loss_fre_HH

        loss_total = 15 * loss_gra + 12*loss_clip1 + 15 * loss_fre_total
        #
        return loss_total, loss_gra, loss_clip1, loss_fre_total
        # return loss_fre_total


class Sobelxy(nn.Module):
    def __init__(self):
        super(Sobelxy, self).__init__()
        kernelx = [[-1, 0, 1],
                   [-2, 0, 2],
                   [-1, 0, 1]]
        kernely = [[1, 2, 1],
                   [0, 0, 0],
                   [-1, -2, -1]]
        kernelx = torch.FloatTensor(kernelx).unsqueeze(0).unsqueeze(0)
        kernely = torch.FloatTensor(kernely).unsqueeze(0).unsqueeze(0)
        self.weightx = nn.Parameter(data=kernelx, requires_grad=False).cuda()
        self.weighty = nn.Parameter(data=kernely, requires_grad=False).cuda()

    def forward(self, x):
        sobelx = F.conv2d(x, self.weightx, padding=1)
        sobely = F.conv2d(x, self.weighty, padding=1)
        return torch.abs(sobelx) + torch.abs(sobely)


def get_wav(in_channels, pool=True):
    """wavelet decomposition using conv2d"""
    harr_wav_L = 1 / np.sqrt(2) * np.ones((1, 2))
    harr_wav_H = 1 / np.sqrt(2) * np.ones((1, 2))
    harr_wav_H[0, 0] = -1 * harr_wav_H[0, 0]

    harr_wav_LL = np.transpose(harr_wav_L) * harr_wav_L
    harr_wav_LH = np.transpose(harr_wav_L) * harr_wav_H
    harr_wav_HL = np.transpose(harr_wav_H) * harr_wav_L
    harr_wav_HH = np.transpose(harr_wav_H) * harr_wav_H

    filter_LL = torch.from_numpy(harr_wav_LL).unsqueeze(0)
    #  print(filter_LL.size())
    filter_LH = torch.from_numpy(harr_wav_LH).unsqueeze(0)
    filter_HL = torch.from_numpy(harr_wav_HL).unsqueeze(0)
    filter_HH = torch.from_numpy(harr_wav_HH).unsqueeze(0)

    if pool:
        net = nn.Conv2d
    else:
        net = nn.ConvTranspose2d
    LL = net(in_channels, in_channels,
             kernel_size=2, stride=1, padding=0, bias=False,
             groups=in_channels)
    LH = net(in_channels, in_channels,
             kernel_size=2, stride=1, padding=0, bias=False,
             groups=in_channels)
    HL = net(in_channels, in_channels,
             kernel_size=2, stride=1, padding=0, bias=False,
             groups=in_channels)
    HH = net(in_channels, in_channels,
             kernel_size=2, stride=1, padding=0, bias=False,
             groups=in_channels)

    LL.weight.requires_grad = False
    LH.weight.requires_grad = False
    HL.weight.requires_grad = False
    HH.weight.requires_grad = False

    LL.weight.data = filter_LL.float().unsqueeze(0).expand(in_channels, -1, -1, -1).cuda()
    LH.weight.data = filter_LH.float().unsqueeze(0).expand(in_channels, -1, -1, -1).cuda()
    HL.weight.data = filter_HL.float().unsqueeze(0).expand(in_channels, -1, -1, -1).cuda()
    HH.weight.data = filter_HH.float().unsqueeze(0).expand(in_channels, -1, -1, -1).cuda()

    return LL, LH, HL, HH


class WavePool(nn.Module):
    def __init__(self, in_channels):
        super(WavePool, self).__init__()
        self.LL, self.LH, self.HL, self.HH = get_wav(1)

    def forward(self, x):
        return self.LL(x), self.LH(x), self.HL(x), self.HH(x)


import torch.nn.functional as F
import torch
from math import exp
import torch.nn as nn

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def ir_loss(fused_result, input_ir):
    a = fused_result - input_ir
    b = torch.square(fused_result - input_ir)
    c = torch.mean(torch.square(fused_result - input_ir))
    ir_loss = c
    return ir_loss


def vi_loss(fused_result, input_vi):
    vi_loss = torch.mean(torch.square(fused_result - input_vi))
    return vi_loss


def ssim_loss(fused_result, input_ir, input_vi):
    ssim_loss = ssim(fused_result, torch.maximum(input_ir, input_vi))

    return ssim_loss


def gra_loss(fused_result, input_ir, input_vi):
    gra_loss = torch.norm(Gradient(fused_result) - torch.maximum(Gradient(input_ir), Gradient(input_vi)))
    return gra_loss


def gaussian(window_size, sigma):
    gauss = torch.Tensor([exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)])
    return gauss / gauss.sum()


def create_window(window_size, channel=1):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
    return window


def ssim(img1, img2, window_size=11, window=None, val_range=None):
    if val_range is None:
        if torch.max(img1) > 128:
            max_val = 255
        else:
            max_val = 1

        if torch.min(img1) < -0.5:
            min_val = -1
        else:
            min_val = 0
        L = max_val - min_val
    else:
        L = val_range

    padd = 0
    (_, channel, height, width) = img1.size()
    if window is None:
        real_size = min(window_size, height, width)
        window = create_window(real_size, channel=channel).to(img1.device)
    mu1 = F.conv2d(img1, window, padding=padd, groups=channel)
    mu2 = F.conv2d(img2, window, padding=padd, groups=channel)
    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2
    sigma1_sq = F.conv2d(img1 * img1, window, padding=padd, groups=channel) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, window, padding=padd, groups=channel) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, window, padding=padd, groups=channel) - mu1_mu2
    C1 = (0.01 * L) ** 2
    C2 = (0.03 * L) ** 2
    v1 = 2.0 * sigma12 + C2
    v2 = sigma1_sq + sigma2_sq + C2
    ssim_map = ((2 * mu1_mu2 + C1) * v1) / ((mu1_sq + mu2_sq + C1) * v2)
    ret = ssim_map.mean()
    return 1 - ret


class gradient(nn.Module):
    def __init__(self):
        super(gradient, self).__init__()
        x_kernel = [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]
        y_kernel = [[1, 2, 1], [0, 0, 0], [-1, -2, -1]]
        x_kernel = torch.FloatTensor(x_kernel).unsqueeze(0).unsqueeze(0)
        y_kernel = torch.FloatTensor(y_kernel).unsqueeze(0).unsqueeze(0)
        self.x_weight = nn.Parameter(data=x_kernel, requires_grad=False)
        self.y_weight = nn.Parameter(data=y_kernel, requires_grad=False)

    def forward(self, input):
        x_grad = torch.nn.functional.conv2d(input, self.x_weight, padding=1)
        y_grad = torch.nn.functional.conv2d(input, self.y_weight, padding=1)
        gradRes = torch.mean((x_grad + y_grad).float())
        return gradRes


def Gradient(x):
    gradient_model = gradient().to(device)
    g = gradient_model(x)
    return g


if __name__ == '__main__':
    pass

