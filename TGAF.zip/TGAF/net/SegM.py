import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_
import math
# from net.SAttention import VitPatchEmbed, VitPosEmbed2d, ViLBlock, SequenceTraversal
from torch import nn
from torch.cuda.amp import autocast
# from .SAttention import ViLBlock, SequenceTraversal
from einops import rearrange
from einops.layers.torch import Rearrange
from torch import Tensor
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from .FANLayer import FANLayer

from .AAF import AAF
# from .TIF import TIF
import numpy as np
from .SResFormer import SResFormer


def RGB2YCrCb(input_im):
    im_flat = input_im.transpose(1, 3).transpose(
        1, 2).reshape(-1, 3)  # (nhw,c)
    R = im_flat[:, 0]
    G = im_flat[:, 1]
    B = im_flat[:, 2]
    Y = 0.299 * R + 0.587 * G + 0.114 * B
    Cr = (R - Y) * 0.713 + 0.5
    Cb = (B - Y) * 0.564 + 0.5
    Y = torch.unsqueeze(Y, 1)
    Cr = torch.unsqueeze(Cr, 1)
    Cb = torch.unsqueeze(Cb, 1)
    temp = torch.cat((Y, Cr, Cb), dim=1).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out


def YCrCb2RGB(input_im):
    im_flat = input_im.transpose(1, 3).transpose(1, 2).reshape(-1, 3)
    mat = torch.tensor(
        [[1.0, 1.0, 1.0], [1.403, -0.714, 0.0], [0.0, -0.344, 1.773]]
    ).cuda()
    bias = torch.tensor([0.0 / 255, -0.5, -0.5]).cuda()
    temp = (im_flat + bias).mm(mat).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out


import torch
import torch.nn as nn
import torch.nn.functional as F






class DRDB1(nn.Module):
    def __init__(self, in_ch=64, growth_rate=32):
        super(DRDB1, self).__init__()
        in_ch_ = in_ch
        self.Dcov1 = PSConv(in_ch_, growth_rate, 3, s=1)
        in_ch_ += growth_rate
        self.Dcov2 = PSConv(in_ch_, growth_rate, 3, s=1)
        in_ch_ += growth_rate
        self.Dcov3 = PSConv(in_ch_, growth_rate, 3, s=1)
        in_ch_ += growth_rate
        self.Dcov4 = PSConv(in_ch_, growth_rate, 3, s=1)
        in_ch_ += growth_rate
        self.Dcov5 = PSConv(in_ch_, growth_rate, 3, s=1)
        in_ch_ += growth_rate
        print(in_ch_, in_ch)
        self.conv = PSConv(in_ch_, in_ch, 3,s=1)


    def forward(self, x):
        # B, C1, H, W = x.shape
        x1 = self.Dcov1(x)
        x1 = F.relu(x1)
        x1 = torch.cat([x, x1], dim=1)

        x2 = self.Dcov2(x1)
        x2 = F.relu(x2)
        x2 = torch.cat([x1, x2], dim=1)

        x3 = self.Dcov3(x2)
        x3 = F.relu(x3)
        x3 = torch.cat([x2, x3], dim=1)

        x4 = self.Dcov4(x3)
        x4 = F.relu(x4)
        x4 = torch.cat([x3, x4], dim=1)

        x5 = self.Dcov5(x4)
        x5 = F.relu(x5)
        x5 = torch.cat([x4, x5], dim=1)
        # B, C, H, W = x5.shape
        # x5 = x5.permute(0,2, 3, 1).reshape(-1,C)
        x6 = self.conv(x5)
        # x6 = x6.reshape(B, H, W, C1).permute(0, 3, 1, 2)
        out = x + F.relu(x6)
        return out


class DRDB(nn.Module):
    def __init__(self, in_ch=64, growth_rate=32):
        super(DRDB, self).__init__()
        in_ch_ = in_ch
        self.Dcov1 = nn.Conv2d(in_ch_, growth_rate, 3, padding=2, dilation=2)
        in_ch_ += growth_rate
        self.Dcov2 = nn.Conv2d(in_ch_, growth_rate, 3, padding=2, dilation=2)
        in_ch_ += growth_rate
        self.Dcov3 = nn.Conv2d(in_ch_, growth_rate, 3, padding=2, dilation=2)
        in_ch_ += growth_rate
        self.Dcov4 = nn.Conv2d(in_ch_, growth_rate, 3, padding=2, dilation=2)
        in_ch_ += growth_rate
        self.Dcov5 = nn.Conv2d(in_ch_, growth_rate, 3, padding=2, dilation=2)
        in_ch_ += growth_rate
        print(in_ch_, in_ch)
        self.conv = nn.Conv2d(in_ch_, in_ch, 1, padding=0)
        #self.conv = KANLinear(in_features=in_ch_,out_features=in_ch)

    def forward(self, x):
        # B, C1, H, W = x.shape
        x1 = self.Dcov1(x)
        x1 = F.relu(x1)
        x1 = torch.cat([x, x1], dim=1)

        x2 = self.Dcov2(x1)
        x2 = F.relu(x2)
        x2 = torch.cat([x1, x2], dim=1)

        x3 = self.Dcov3(x2)
        x3 = F.relu(x3)
        x3 = torch.cat([x2, x3], dim=1)

        x4 = self.Dcov4(x3)
        x4 = F.relu(x4)
        x4 = torch.cat([x3, x4], dim=1)

        x5 = self.Dcov5(x4)
        x5 = F.relu(x5)
        x5 = torch.cat([x4, x5], dim=1)
        # B, C, H, W = x5.shape
        # x5 = x5.permute(0,2, 3, 1).reshape(-1,C)
        x6 = self.conv(x5)
        # x6 = x6.reshape(B, H, W, C1).permute(0, 3, 1, 2)
        out = x + F.relu(x6)
        return out



class CrossAttention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None):
        super(CrossAttention, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        # self.kv1 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        # self.kv2 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        # self.kv3 = nn.Linear(dim, dim * 2, bias=qkv_bias)

    def forward(self, x1, x2, textA, textB):
        B, N, C = x1.shape
        q1 = x1.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        q2 = x2.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        # q2 = x2.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()

        # transpose: -> [batch_size, num_heads, embed_dim_per_head, num_patches + 1]
        # @: multiply -> [batch_size, num_heads, num_patches + 1, num_patches + 1]

        # k1, v1 = self.kv1(x1).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        # k2, v2 = self.kv2(x2).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        k3, v3 = textA.reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1,
                                                                                     4).contiguous()
        k4, v4 = textB.reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1,
                                                                                     4).contiguous()

        # ctx1 = (k1.transpose(-2, -1) @ v1) * self.scale
        # ctx1 = ctx1.softmax(dim=-2)
        # ctx2 = (k2.transpose(-2, -1) @ v2) * self.scale
        # ctx2 = ctx2.softmax(dim=-2)

        ctx3 = (k3.transpose(-2, -1) @ v3) * self.scale
        ctx3 = ctx3.softmax(dim=-2)
        # ctx4 = (k3.transpose(-2, -1) @ v4) * self.scale
        # ctx4 = ctx3.softmax(dim=-2)
        ctx4 = (k4.transpose(-2, -1) @ v4) * self.scale
        ctx4 = ctx4.softmax(dim=-2)

        x1 = (q1 @ ctx3).permute(0, 2, 1, 3).reshape(B, N, C).contiguous()

        x2 = (q2 @ ctx4).permute(0, 2, 1, 3).reshape(B, N, C).contiguous()

        return x1, x2


class CrossAttention2(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None):
        super(CrossAttention2, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.kv1 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.kv2 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        # self.kv3 = nn.Linear(dim, dim * 2, bias=qkv_bias)

    def forward(self, x1, x2, textA, textB):
        B, N, C = x1.shape
        # q1 = x1.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        # q2 = x2.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        q3 = textA.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        q4 = textB.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        q1 = x1.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        # transpose: -> [batch_size, num_heads, embed_dim_per_head, num_patches + 1]
        # @: multiply -> [batch_size, num_heads, num_patches + 1, num_patches + 1]

        k1, v1 = self.kv1(x1).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        k2, v2 = self.kv2(x2).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        # k3, v3 = self.kv3(segfeature).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()

        ctx1 = (k1.transpose(-2, -1) @ v1) * self.scale
        ctx1 = ctx1.softmax(dim=-2)
        ctx2 = (k2.transpose(-2, -1) @ v2) * self.scale
        ctx2 = ctx2.softmax(dim=-2)
        #
        # ctx3 = (k3.transpose(-2, -1) @ v3) * self.scale
        # ctx3 = ctx3.softmax(dim=-2)
        # print(q1.shape)
        # print(q3.shape)
        # print(ctx1.shape)
        # q1 = q1.squeeze(0)  # 去除第一个维度
        # q3 = q3.squeeze(0)  # 去除第一个维度
        # print(q1.shape)
        # print(q3.shape)
        batch_size, patch_size, number_patch, patch_size = q3.shape
        q3 = q3.permute(0, 2, 1, 3).reshape(batch_size, number_patch, patch_size * patch_size)
        q4 = q4.permute(0, 2, 1, 3).reshape(batch_size, number_patch, patch_size * patch_size)

        # 第二步：使用插值，将 q3 调整到与 q1 的第二个维度相同的大小
        target_height = q1.shape[2]


        # print(q3.shape)
        # 计算裁剪长度和偏移量
        q3 = F.interpolate(q3.unsqueeze(1), size=(target_height, q3.shape[2]), mode='bilinear', align_corners=False).squeeze(1)
        # 第三步：将 q3 恢复为形状 [batch_size, channel, target_height, width]，不使用具体数字
        q3 = q3.reshape(batch_size, target_height, patch_size, patch_size).permute(0, 2, 1, 3)
        q4 = F.interpolate(q4.unsqueeze(1), size=(target_height, q4.shape[2]), mode='bilinear',
                           align_corners=False).squeeze(1)
        # 第三步：将 q3 恢复为形状 [batch_size, channel, target_height, width]，不使用具体数字
        q4 = q4.reshape(batch_size, target_height, patch_size, patch_size).permute(0, 2, 1, 3)

        x1 = (q3 @ ctx1).permute(0, 2, 1, 3).reshape(B, -1, C).contiguous()
        x2 = (q4 @ ctx2).permute(0, 2, 1, 3).reshape(B, -1, C).contiguous()


        return x1, x2


class CrossPath(nn.Module):
    def __init__(self, dim, reduction=1, num_heads=8, norm_layer=nn.LayerNorm):
        super().__init__()
        self.channel_proj1 = nn.Linear(dim, dim // reduction * 2)
        self.channel_proj2 = nn.Linear(dim, dim // reduction * 2)
        self.channel_proj3 = nn.Linear(dim, dim // reduction * 2)
        self.channel_proj4 = nn.Linear(dim, dim // reduction * 2)

        self.act1 = nn.ReLU(inplace=True)
        self.act2 = nn.ReLU(inplace=True)
        self.act3 = nn.ReLU(inplace=True)

        self.cross_attn = CrossAttention(dim // reduction, num_heads=num_heads)
        self.cross_attn2 = CrossAttention2(dim // reduction, num_heads=num_heads)

        self.end_proj1 = nn.Linear(dim // reduction * 2, dim)
        self.end_proj2 = nn.Linear(dim // reduction * 2, dim)
        # self.end_proj2 = nn.Linear(dim // reduction * 2, dim)

        self.norm1 = norm_layer(dim)
        self.norm2 = norm_layer(dim)

    def forward(self, x1, x2, textA, textB):
        y1, u1 = self.act1(self.channel_proj1(x1)).chunk(2, dim=-1)  # 分离querry和key
        y2, u2 = self.act2(self.channel_proj2(x2)).chunk(2, dim=-1)
        y3, u3 = self.act3(self.channel_proj3(textA)).chunk(2, dim=-1)
        y4, u4 = self.act3(self.channel_proj3(textA)).chunk(2, dim=-1)

        v1, v2 = self.cross_attn(u1, u2, u3, u4)
        z1, z2 = self.cross_attn2(y1, y2, y3, y4)
        y1 = torch.cat((z1, v1), dim=-1)
        y2 = torch.cat((z2, v2), dim=-1)
        out_x1 = self.norm1(x1 + self.end_proj1(y1))
        out_x2 = self.norm2(x2 + self.end_proj2(y2))
        return out_x1, out_x2


class FeatureFusionModule(nn.Module):
    def __init__(self, dim, reduction=1, num_heads=8, norm_layer=nn.BatchNorm2d):
        super().__init__()
        self.cross = CrossPath(dim=dim, reduction=reduction, num_heads=num_heads)
        # self.channel_emb = ChannelEmbed(in_channels=dim * 2, out_channels=dim, reduction=reduction,
        #                                 norm_layer=norm_layer)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x1, x2, textA, textB):
        B, C, H, W = x1.shape
        x1 = x1.flatten(2).transpose(1, 2)
        x2 = x2.flatten(2).transpose(1, 2)
        x3 = textA.flatten(2).transpose(1, 2)
        x4 = textB.flatten(2).transpose(1, 2)
        x1, x2 = self.cross(x1, x2, x3, x4)
        # merge = torch.cat((x1, x2), dim=-1)
        # merge = self.channel_emb(merge, H, W)
        x1 = x1.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        x2 = x2.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        return x1, x2


class Net(nn.Module):
    def __init__(self,n_feat=64):
        super(Net, self,).__init__()

        self.conv1_ir = nn.Conv2d(1, n_feat, 1, padding=0)
        self.conv1_vis = nn.Conv2d(1, n_feat, 1, padding=0)


        self.fem1 = Fem(n_feat, n_feat)
        self.fem2 = Fem(n_feat, n_feat)

        self.DB1 = DRDB(in_ch=n_feat)
        self.DB2 = DRDB(in_ch=n_feat)


        self.conv21 = nn.Conv2d(2*n_feat, n_feat, 3, padding=1)
        self.conv22 = nn.Conv2d(2 * n_feat, n_feat, 3, padding=1)


        self.relu = nn.PReLU()

        self.ffm1 = FeatureFusionModule(n_feat)


        self.conv3_A = nn.Conv2d(1, n_feat, 1, padding=0)
        self.ffn1 = FANLayer(n_feat,n_feat)
        self.conv3_B = nn.Conv2d(1, n_feat, 1, padding=0)
        self.ffn2 = FANLayer(n_feat, n_feat)

        self.conv_f = nn.Conv2d(n_feat, 1, 3, padding=1)



        self.fusion = AAF(n_feat)
        # self.conv4 = nn.Conv2d(128, 64, 3, padding=1)
        self.Conv0 = ConvBnLeakyRelu2d(1, 64)
        self.ca=ChannelAttention(n_feat, 16)

        self.trans1 =SResFormer(dim=n_feat)
        self.trans2 =SResFormer(dim=n_feat)
        self.trans3 = SResFormer(dim=n_feat)

    def forward(self, ir, vis, textA, textB):
        max = torch.max(ir, vis)
        max = self.ca(self.relu(self.Conv0(max)))


        textA = textA.unsqueeze(1)
        textB = textB.unsqueeze(1)

        ir = self.conv1_ir(ir)


        ir = self.relu(ir)


        ir = self.DB1(ir)

        vis = self.conv1_vis(vis)
        vis = self.relu(vis)

        vis = self.DB2(vis)

        # ir, vis = self.ffm2(ir, vis, self.conv3_A(textA), self.conv3_B(textB))



        x1 =self.fem1(ir)

        trans_ir = self.trans1(ir)

        res = self.conv21(torch.cat((x1, trans_ir), dim=1))
        x1 = ir + res



        x2 = self.fem2(vis)

        trans_vis = self.trans2(vis)

        res = self.conv22(torch.cat((x2, trans_vis), dim=1))
        x2 = vis + res
        textAf = self.conv3_A(textA)
        textBf = self.conv3_B(textB)
        textAf = textAf.permute(0, 2, 3, 1)
        # # print(f_final.shape)
        textAf = self.ffn1(textAf)
        textAf = textAf.permute(0, 3, 1, 2)
        textBf = textBf.permute(0, 2, 3, 1)
        # # print(f_final.shape)
        textBf = self.ffn2(textBf)
        textBf = textBf.permute(0, 3, 1, 2)
        x1, x2 = self.ffm1(x1, x2, textAf, textBf)
        # x1, x2 = self.ffm1(x1, x2, self.conv3_A(textA),self.conv3_B(textB))
        # x1 = self.DRDB3(x1)
        # x2 = self.DRDB4(x2)

        f_final  = self.fusion(x1,x2)+0.2*max
        # f_final = self.relu(self.conv4((torch.cat([x1,x2],dim=1))))+max
        f_final = self.trans3(f_final)
        # f_final = self.trans3(f_final)

        # print(f_final.shape)
        # print(sobel.shape)

        f_final = self.relu(self.conv_f(f_final))
        # f_final = self.relu(self.conv_f2(f_final))
        # f_final = self.relu(self.conv_f1(f_final))
        # f_final = self.relu(self.conv_f2(f_final))
        return f_final


class ConvBnLeakyRelu2d(nn.Module):
    # convolution
    # batch normalization
    # leaky relu
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1, stride=1, dilation=1, groups=1):
        super(ConvBnLeakyRelu2d, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=padding, stride=stride, dilation=dilation, groups=groups)
        self.bn  = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        # return F.leaky_relu(self.conv(x), negative_slope=0.2)
        return self.conv(x)
        # return F.leaky_relu(self.bn(self.conv(x)), negative_slope=0.2)

class GroupBatchnorm2d(nn.Module):
    def __init__(self, c_num: int,
                 group_num: int = 16,
                 eps: float = 1e-10
                 ):
        super(GroupBatchnorm2d, self).__init__()
        assert c_num >= group_num
        self.group_num = group_num
        self.weight = nn.Parameter(torch.randn(c_num, 1, 1))
        self.bias = nn.Parameter(torch.zeros(c_num, 1, 1))
        self.eps = eps

    def forward(self, x):
        N, C, H, W = x.size()
        x = x.reshape(N, self.group_num, -1)
        mean = x.mean(dim=2, keepdim=True)
        std = x.std(dim=2, keepdim=True)
        x = (x - mean) / (std + self.eps)
        x = x.view(N, C, H, W)
        return x * self.weight + self.bias

class SRU(nn.Module):
    def __init__(self,
                 oup_channels: int,
                 group_num: int = 16,
                 gate_treshold: float = 0.5,
                 torch_gn: bool = False
                 ):
        super().__init__()

        self.gn = nn.GroupNorm(num_channels=oup_channels, num_groups=group_num) if torch_gn else GroupBatchnorm2d(
            c_num=oup_channels, group_num=group_num)
        self.gate_treshold = gate_treshold
        self.sigomid = nn.Sigmoid()

    def forward(self, x):
        gn_x = self.gn(x)
        w_gamma = self.gn.weight / torch.sum(self.gn.weight)
        w_gamma = w_gamma.view(1, -1, 1, 1)
        reweigts = self.sigomid(gn_x * w_gamma)
        # Gate
        info_mask = reweigts >= self.gate_treshold
        noninfo_mask = reweigts < self.gate_treshold
        x_1 = info_mask * gn_x
        x_2 = noninfo_mask * gn_x
        x = self.reconstruct(x_1, x_2)
        return x

    def reconstruct(self, x_1, x_2):
        x_11, x_12 = torch.split(x_1, x_1.size(1) // 2, dim=1)
        x_21, x_22 = torch.split(x_2, x_2.size(1) // 2, dim=1)
        return torch.cat([x_11 + x_22, x_12 + x_21], dim=1)


class CRU(nn.Module):
    '''
    alpha: 0<alpha<1
    '''

    def __init__(self,
                 op_channel: int,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        self.up_channel = up_channel = int(alpha * op_channel)
        self.low_channel = low_channel = op_channel - up_channel
        self.squeeze1 = nn.Conv2d(up_channel, up_channel // squeeze_radio, kernel_size=1, bias=False)
        self.squeeze2 = nn.Conv2d(low_channel, low_channel // squeeze_radio, kernel_size=1, bias=False)
        # up
        self.GWC = nn.Conv2d(up_channel // squeeze_radio, op_channel, kernel_size=group_kernel_size, stride=1,
                             padding=group_kernel_size // 2, groups=group_size)
        self.PWC1 = nn.Conv2d(up_channel // squeeze_radio, op_channel, kernel_size=1, bias=False)
        # low
        self.PWC2 = nn.Conv2d(low_channel // squeeze_radio, op_channel - low_channel // squeeze_radio, kernel_size=1,
                              bias=False)
        self.advavg = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        # Split
        up, low = torch.split(x, [self.up_channel, self.low_channel], dim=1)
        up, low = self.squeeze1(up), self.squeeze2(low)
        # Transform
        Y1 = self.GWC(up) + self.PWC1(up)
        Y2 = torch.cat([self.PWC2(low), low], dim=1)
        # Fuse
        out = torch.cat([Y1, Y2], dim=1)
        out = F.softmax(self.advavg(out), dim=1) * out
        out1, out2 = torch.split(out, out.size(1) // 2, dim=1)
        return out1 + out2


class ScConv(nn.Module):
    def __init__(self,
                 op_channel: int,
                 group_num: int = 4,
                 gate_treshold: float = 0.5,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        self.SRU = SRU(op_channel,
                       group_num=group_num,
                       gate_treshold=gate_treshold)
        self.CRU = CRU(op_channel,
                       alpha=alpha,
                       squeeze_radio=squeeze_radio,
                       group_size=group_size,
                       group_kernel_size=group_kernel_size)

    def forward(self, x):
        x = self.SRU(x)
        x = self.CRU(x)
        return x

class Fem(nn.Module):
    def __init__(self,  in_channel, out_channel):
        super(Fem, self).__init__()
        self.padding = (1, 1, 1, 1)
        self.ScConv = ScConv(in_channel)#add it myself
        #self.RFAConv = RFAConv(in_channel,out_channel)
        #self.Pconv = Partial_conv3(16,4,'split_cat')
        #self.conv=nn.Conv2d(in_channel,out_channel,kernel_size=3,padding=0,stride=1)
        self.bn=nn.BatchNorm2d(out_channel)
        self.relu=nn.ReLU(inplace=True)
        # self.ca=ChannelAttention(in_channel, 16)

    def forward(self, input):
        # out = F.pad(input, self.padding, 'replicate')
        # out=self.conv(out)
        out = self.ScConv(input)
        #out = self.RFAConv(out)
        out=self.bn(out)
        out=self.relu(out)
        # out = F.pad(out, self.padding, 'replicate')
        # out=self.conv(out)
        out = self.ScConv(out)
        out = self.bn(out)
        # out = self.ca(out)
        return out
class ChannelAttention(nn.Module):
    """Channel attention used in RCAN.
    Args:
        num_feat (int): Channel number of intermediate features.
        squeeze_factor (int): Channel squeeze factor. Default: 16.
    """

    def __init__(self, num_feat, squeeze_factor=16):
        super(ChannelAttention, self).__init__()
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(num_feat, num_feat // squeeze_factor, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_feat // squeeze_factor, num_feat, 1, padding=0),
            nn.Sigmoid())

    def forward(self, x):
        y = self.attention(x)
        return x * y


class CAB(nn.Module):

    def __init__(self, num_feat, compress_ratio=3, squeeze_factor=30):
        super(CAB, self).__init__()

        self.cab = nn.Sequential(
            nn.Conv2d(num_feat, num_feat // compress_ratio, 3, 1, 1),
            nn.GELU(),
            nn.Conv2d(num_feat // compress_ratio, num_feat, 3, 1, 1),
            ChannelAttention(num_feat, squeeze_factor)
            )

    def forward(self, x):
        return self.cab(x)
##########################################################################
## Resizing modules


