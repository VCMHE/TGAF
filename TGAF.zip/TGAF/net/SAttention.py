# This file is licensed under AGPL-3.0
# Copyright (c) NXAI GmbH and its affiliates 2024
# Benedikt Alkin, Maximilian Beck, Korbinian Pöppel
import math
from enum import Enum
from einops import rearrange
import einops
import torch
import torch.nn.functional as F
from torch import nn
from .FANLayer import FANLayer

class DropPath(nn.Sequential):
    """
    Efficiently drop paths (Stochastic Depth) per sample such that dropped samples are not processed.
    This is a subclass of nn.Sequential and can be used either as standalone Module or like nn.Sequential.
    Examples::
        >>> # use as nn.Sequential module
        >>> sequential_droppath = DropPath(nn.Linear(4, 4), drop_prob=0.2)
        >>> y = sequential_droppath(torch.randn(10, 4))

        >>> # use as standalone module
        >>> standalone_layer = nn.Linear(4, 4)
        >>> standalone_droppath = DropPath(drop_prob=0.2)
        >>> y = standalone_droppath(torch.randn(10, 4), standalone_layer)
    """

    def __init__(self, *args, drop_prob: float = 0., scale_by_keep: bool = True, stochastic_drop_prob: bool = False):
        super().__init__(*args)
        assert 0. <= drop_prob < 1.
        self._drop_prob = drop_prob
        self.scale_by_keep = scale_by_keep
        self.stochastic_drop_prob = stochastic_drop_prob

    @property
    def drop_prob(self):
        return self._drop_prob

    @drop_prob.setter
    def drop_prob(self, value):
        assert 0. <= value < 1.
        self._drop_prob = value

    @property
    def keep_prob(self):
        return 1. - self.drop_prob

    def forward(self, x, residual_path=None, residual_path_kwargs=None):
        assert (len(self) == 0) ^ (residual_path is None)
        residual_path_kwargs = residual_path_kwargs or {}
        if self.drop_prob == 0. or not self.training:
            if residual_path is None:
                return x + super().forward(x, **residual_path_kwargs)
            else:
                return x + residual_path(x, **residual_path_kwargs)
        # generate indices to keep (propagated through transform path)
        bs = len(x)
        if self.stochastic_drop_prob:
            perm = torch.empty(bs, device=x.device).bernoulli_(self.keep_prob).nonzero().squeeze(1)
            scale = 1 / self.keep_prob
        else:
            keep_count = max(int(bs * self.keep_prob), 1)
            scale = bs / keep_count
            perm = torch.randperm(bs, device=x.device)[:keep_count]

        # propagate
        if self.scale_by_keep:
            alpha = scale
        else:
            alpha = 1.
        # reduce kwargs (e.g. used for DiT block where scale/shift/gate is passed and also has to be reduced)
        residual_path_kwargs = {
            key: value[perm] if torch.is_tensor(value) else value
            for key, value in residual_path_kwargs.items()
        }
        if residual_path is None:
            residual = super().forward(x[perm], **residual_path_kwargs)
        else:
            residual = residual_path(x[perm], **residual_path_kwargs)
        return torch.index_add(
            x.flatten(start_dim=1),
            dim=0,
            index=perm,
            source=residual.to(x.dtype).flatten(start_dim=1),
            alpha=alpha,
        ).view_as(x)

    def extra_repr(self):
        return f'drop_prob={round(self.drop_prob, 3):0.3f}'



class CausalConv1d(nn.Module):
    """
    Implements causal depthwise convolution of a time series tensor.
    Input:  Tensor of shape (B,T,F), i.e. (batch, time, feature)
    Output: Tensor of shape (B,T,F)

    Args:
        feature_dim: number of features in the input tensor
        kernel_size: size of the kernel for the depthwise convolution
        causal_conv_bias: whether to use bias in the depthwise convolution
        channel_mixing: whether to use channel mixing (i.e. groups=1) or not (i.e. groups=feature_dim)
                        If True, it mixes the convolved features across channels.
                        If False, all the features are convolved independently.
    """

    def __init__(self, dim, kernel_size=4, bias=True):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size
        self.bias = bias
        # padding of this size assures temporal causality.
        self.pad = kernel_size - 1
        self.conv = nn.Conv1d(
            in_channels=dim,
            out_channels=dim,
            kernel_size=kernel_size,
            padding=self.pad,
            groups=dim,
            bias=bias,
        )
        self.reset_parameters()

    def reset_parameters(self):
        self.conv.reset_parameters()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # conv requires dim first
        x = einops.rearrange(x, "b l d -> b d l")
        # causal conv1d
        x = self.conv(x)
        x = x[:, :, :-self.pad]
        # back to dim last
        x = einops.rearrange(x, "b d l -> b l d")
        return x


class LayerNorm(nn.Module):
    """ LayerNorm but with an optional bias. PyTorch doesn't support simply bias=False. """

    def __init__(
            self,
            ndim: int = -1,
            weight: bool = True,
            bias: bool = False,
            eps: float = 1e-5,
            residual_weight: bool = True,
    ):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros(ndim)) if weight else None
        self.bias = nn.Parameter(torch.zeros(ndim)) if bias else None
        self.eps = eps
        self.residual_weight = residual_weight
        self.ndim = ndim
        self.reset_parameters()

    @property
    def weight_proxy(self) -> torch.Tensor:
        if self.weight is None:
            return None
        if self.residual_weight:
            return 1.0 + self.weight
        else:
            return self.weight

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.layer_norm(
            x,
            normalized_shape=(self.ndim,),
            weight=self.weight_proxy,
            bias=self.bias,
            eps=self.eps,
        )

    def reset_parameters(self):
        if self.weight_proxy is not None:
            if self.residual_weight:
                nn.init.zeros_(self.weight)
            else:
                nn.init.ones_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)











class DyT(nn.Module):
    def __init__(self, num_features, alpha_init_value=0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.ones(1) * alpha_init_value)
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))

    def forward(self, x):
        x = torch.tanh(self.alpha * x)
        return x * self.weight + self.bias

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        self.heads = heads
        self.scale = dim_head ** -0.5

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if (heads != 1 or dim_head != dim) else nn.Identity()

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: t.view(B, N, self.heads, -1).transpose(1, 2), qkv)

        q = q * self.scale
        attn = torch.matmul(q, k.transpose(-1, -2))
        attn = attn.softmax(dim=-1)

        out = torch.matmul(attn, v)
        out = out.transpose(1, 2).reshape(B, N, -1)
        return self.to_out(out)

# class Attention(nn.Module):
#     def __init__(self, dim=64, num_heads=8, bias=True):
#         super(Attention, self).__init__()
#         self.num_heads = num_heads
#         self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
#
#         # 将Conv2d改为Linear层处理序列维度
#         self.qkv = nn.Linear(dim, dim * 3, bias=bias)
#         self.qkv_dwconv = nn.Conv1d(dim * 3, dim * 3, kernel_size=3,
#                                     padding=1, groups=dim * 3, bias=bias)  # 时序深度可分离卷积
#         self.project_out = nn.Linear(dim, dim, bias=bias)
#
#     def forward(self, x):
#         # 输入形状: (B, N, C)
#         B, N, C = x.shape
#
#         # 时序卷积适配
#         qkv = self.qkv(x)  # (B, N, 3C)
#         qkv = qkv.permute(0, 2, 1)  # (B, 3C, N) for Conv1d
#         qkv = self.qkv_dwconv(qkv).permute(0, 2, 1)  # (B, N, 3C)
#
#         # 分割QKV
#         q, k, v = qkv.chunk(3, dim=-1)  # 各为(B, N, C)
#
#         # 多头重组
#         q = rearrange(q, 'B N (h d) -> B h N d', h=self.num_heads)  # h:头数, d:头维度
#         k = rearrange(k, 'B N (h d) -> B h N d', h=self.num_heads)
#         v = rearrange(v, 'B N (h d) -> B h N d', h=self.num_heads)
#
#         # 归一化处理
#         # q = F.normalize(q, dim=-1)
#         # k = F.normalize(k, dim=-1)
#
#         # 注意力计算
#         attn = (q @ k.transpose(-2, -1)) * self.temperature  # (B, h, N, N)
#         attn = attn.softmax(dim=-1)
#
#         # 特征聚合
#         out = attn @ v  # (B, h, N, d)
#
#         # 输出重组
#         out = rearrange(out, 'B h N d -> B N (h d)')  # (B, N, C)
#         out = self.project_out(out)
#
#         return out

class ChannelReductionAttention(nn.Module):
    def __init__(self, dim, reduced_ratio=4):
        super(ChannelReductionAttention, self).__init__()

        reduced_channels = dim // reduced_ratio
        # self.dim2 = dim2
        # self.pool_ratio = pool_ratio
        # self.num_heads = num_heads
        # head_dim = dim1 // num_heads
        #
        # self.scale = qk_scale or head_dim ** -0.5

        self.q = nn.Linear(dim, reduced_channels)
        self.k = nn.Linear(dim, reduced_channels)
        self.v = nn.Linear(dim, dim)
        # self.attn_drop = nn.Dropout(attn_drop)
        # self.proj = nn.Linear(dim1, dim1)
        # self.proj_drop = nn.Dropout(proj_drop)
        #
        # self.pool = nn.AvgPool2d(pool_ratio, pool_ratio)
        # self.sr = nn.Conv2d(dim1, dim1, kernel_size=1, stride=1)
        # self.norm = nn.LayerNorm(dim1)
        # self.act = nn.GELU()
        # self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        # B, C, H, W = x.size()
        B, N, C = x.size()
        input_flat = x.permute(0, 2, 1)
        avg_pool = torch.mean(input_flat, dim=-1, keepdim=True)

        q = self.q(input_flat.permute(0, 2, 1))

        # x_ = x.permute(0, 2, 1).reshape(B, C, h, w)
        # x_ = self.sr(self.pool(x_)).reshape(B, C, -1).permute(0, 2, 1)
        # x_ = self.norm(x_)
        # x_ = self.act(x_)
        k = self.k(avg_pool.permute(0, 2, 1))
        v = self.v(avg_pool.permute(0, 2, 1))
        # attn = (q @ k.transpose(-2, -1)) * self.scale
        # attn = attn.softmax(dim=-1)
        # attn = self.attn_drop(attn)
        attn = torch.softmax(torch.bmm(q, k.permute(0, 2, 1)), dim=1)

        # x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        #
        # x = self.proj(x)
        # x = self.proj_drop(x)
        out = torch.bmm(attn, v)

        out = out.view(B, N, C)

        return out

class satt(nn.Module):
    def __init__(self, dim,  drop_path=0.0, norm_bias=False):
        super().__init__()
        self.dim = dim

        self.drop_path = drop_path
        self.norm_bias = norm_bias

        self.drop_path = DropPath(drop_prob=drop_path)
        # self.norm1 = nn.LayerNorm(dim)
        self.norm1 = DyT(num_features=dim)
        # self.layer = Attention(dim)
        self.layer = ChannelReductionAttention(dim)
        #self.layer = ViLLayer(dim=dim, direction=direction)
        self.norm2 = DyT(num_features=dim)
        # self.norm2 = nn.LayerNorm(dim)
        # self.ffn = FeedForward(dim=dim,hidden_dim=128)
        self.ffn = FANLayer(input_dim=dim, output_dim=dim)
        # self.reset_parameters()

    def _forward_path(self, x):
        # x = self.norm(x)
        # x = self.layer(x)
        x = x + self.norm1(self.layer(x))
        x = x + self.norm2(self.ffn(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.drop_path(x, self._forward_path)
        # print('In xlstm now')
        return x








