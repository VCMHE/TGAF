import torch
# from thop import profile, clever_format
from torch import nn
from torch.cuda.amp import autocast

from .SAttention import satt
import torch.nn.functional as F

from .FANLayer import FANLayer





class SResFormer(nn.Module):
    def __init__(self, dim, d_state=16, d_conv=4, expand=2, channel_token=False, LayerNorm_type='WithBias'):
        super().__init__()
        # print(f"ViLLayer: dim: {dim}")
        self.dim = dim
        # self.norm1 = SelfNorm(chan_num=dim, is_two=True)
        # self.norm2 = SelfNorm(chan_num=dim, is_two=True)
        # self.ffn = FANLayer(input_dim=dim, output_dim=dim)
        self.vil = satt(
            dim=self.dim
        )
        # self.vil = TransformerBlock(dim=dim, num_heads=4, ffn_expansion_factor=2.66,
        #                   bias=False, LayerNorm_type='WithBias')
        self.channel_token = channel_token  ## whether to use channel as tokens
    def forward_patch_token(self, x):


        b, c, h, w = x.shape
        window_size = 1
        pad_h = (window_size - h % window_size) % window_size
        pad_w = (window_size - w % window_size) % window_size
        if pad_h != 0 or pad_w != 0:
            # 填充 seq，以适应 window_partition 操作
            x = F.pad(x, (0, pad_w, 0, pad_h))  # (左，右，上，下)
            padded_h, padded_w = x.shape[2:4]  # 更新填充后的高度和宽度
        x = x.permute(0, 2, 3, 1)
        x = window_partition(x, window_size).permute(0, 3, 1, 2)
        B, d_model = x.shape[:2]
        assert d_model == self.dim
        n_tokens = x.shape[2:].numel()
        img_dims = x.shape[2:]


        # b, c, h, w = x.shape
        # x = x.permute(0, 2, 3, 1)
        # x = window_partition(x, 1).permute(0, 3, 1, 2)
        #
        # B, d_model = x.shape[:2]
        # assert d_model == self.dim
        # n_tokens = x.shape[2:].numel()
        # img_dims = x.shape[2:]


        x_flat = x.reshape(B, d_model, n_tokens).transpose(-1, -2)
        x_vil = self.vil(x_flat)
        out = x_vil.transpose(-1, -2).reshape(B, d_model, *img_dims)

        if pad_h != 0 or pad_w != 0:
            out = window_reverse(out.permute(0, 2, 3, 1), window_size, padded_h, padded_w)

            out = out[:, :h, :w, :].permute(0, 3, 1, 2)  # 去掉填充并还原形状
        else:

            out = window_reverse(out.permute(0, 2, 3, 1), window_size, h, w).permute(0, 3, 1, 2)

        # out = window_reverse(out.permute(0, 2, 3, 1), 1, h, w).permute(0, 3, 1, 2)


        return out

    def forward_channel_token(self, x):

        B, n_tokens = x.shape[:2]
        d_model = x.shape[2:].numel()
        assert d_model == self.dim, f"d_model: {d_model}, self.dim: {self.dim}"
        img_dims = x.shape[2:]
        x_flat = x.flatten(2)
        assert x_flat.shape[2] == d_model, f"x_flat.shape[2]: {x_flat.shape[2]}, d_model: {d_model}"
        x_vil = self.vil(x_flat)
        out = x_vil.reshape(B, n_tokens, *img_dims)

        return out

    @autocast(enabled=False)
    def forward(self, x):
        if x.dtype == torch.float16:
            x = x.type(torch.float32)

        if self.channel_token:
            out = self.forward_channel_token(x)
        else:
            out = self.forward_patch_token(x)

        return out

def window_partition(x, window_size):
    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C)
    return windows
def window_reverse(windows, window_size, H, W):
    B = int(windows.shape[0] / (H * W / window_size / window_size))
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x

if __name__ == '__main__':
    input = torch.randn(1,32,388,284)
    model = SResFormer(32)
    output = model(input)
    print("SResFormer size:", input.size())
    print("SResFormer size:", output.size())
