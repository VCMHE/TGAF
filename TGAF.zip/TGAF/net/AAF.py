import torch
import torch.nn as nn
import torch.nn.functional as F


class Channel_attention(nn.Module):
    def __init__(self,  channel, reduction=4):
        super(Channel_attention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc=nn.Sequential(
            nn.Conv2d(channel,channel//reduction,1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel//reduction,channel,1))
        self.sigmoid=nn.Sigmoid()
    def forward(self, input):
        out=self.avg_pool(input)
        out=self.fc(out)
        out=self.sigmoid(out)
        return out

class Spatial_attention(nn.Module):
    def __init__(self,  channel, reduction=4):
        super(Spatial_attention, self).__init__()
        self.body=nn.Sequential(
            nn.Conv2d(channel, channel//reduction,3,padding=1),
            nn.BatchNorm2d( channel//reduction),
            nn.ReLU(True),

            nn.Conv2d(channel // reduction, 1, 3, padding=1),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )
    def forward(self, input):
        return self.body(input)


class AAF(nn.Module):
    def __init__(self,  channel=512):
        super(AAF, self).__init__()
        self.channel_att = Channel_attention(channel)
        self.spatial_att = Spatial_attention(channel)
        self.sigmoid = nn.Sigmoid()
        self.channel_att2 = Channel_attention(channel)
        self.spatial_att2 = Spatial_attention(channel)
        # self.conv1 = nn.Conv2d(channel, channel, kernel_size=, padding=1)  # 1x1 标准卷积
        self.conv = nn.Conv2d(channel, channel, kernel_size=(1,1), padding=0)  # 1x1 标准卷积
        self.act = nn.GELU()  # GELU 激活函数
    def forward(self,x,residual):
        # att = 1 + F.sigmoid( self.channel_att(in_tensor) * self.spatial_att(in_tensor) )
        # return att * in_tensor
        xa = x + residual
        # Global Perceptron：通过 1x1 卷积和激活函数生成初始的全局表示
        # res = self.conv21(torch.cat((x1, trans_ir), dim=1))
        inputs = self.conv(xa)
        xa = self.act(inputs)
        # xa = self.conv2((torch.cat([x, residual], dim=1)))
        xl = self.channel_att(xa)

        xg = self.spatial_att(xa)
        xlg = xl + xg
        wei = self.sigmoid(xlg)
        xi = x * wei + residual * (1 - wei)
        xi = self.conv(xi)
        xi = self.act(xi)
        xl2 = self.channel_att2(xi)

        xg2 = self.spatial_att2(xi)
        xlg2 = xl2 + xg2
        wei2 = self.sigmoid(xlg2)
        xo = residual * wei2 + x * (1 - wei2)
        return xo



# 测试代码
if __name__ == '__main__':
    cpca = CPCA(channel=256)  # 创建 CPCA 模型，输入通道数为 256
    input = torch.randn(1, 256, 32, 32)  # 生成一个随机输入，大小为 (1, 256, 32, 32)
    input1 = torch.randn(1, 256, 32, 32)  # 生成一个随机输入，大小为 (1, 256, 32, 32)
    output = cpca(input,input1)  # 通过 CPCA 模型进行前向传播
    print(input.shape)  # 打印输入张量的形状
    print(output.shape)  # 打印输出张量的形状