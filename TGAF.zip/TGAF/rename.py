import os

# 目标文件夹路径
# destination_folder = './test_output/Harvard/Gray/'
destination_folder = './test_output/M3FD/Gray1'

# 获取目标文件夹中所有文件的名称
files = os.listdir(destination_folder)

# 过滤出图片文件（假设只处理png图片）
image_files = [file for file in files if file.lower().endswith('.png')]

# 提取文件名中的数字，并根据数字大小进行排序
# image_files.sort(key=lambda x: int(os.path.splitext(x)[0]))
def extract_number(filename):
    match = re.search(r'\d+', filename)  # 提取文件名中的数字部分
    return int(match.group()) if match else float('inf')  # 失败时返回无穷大，确保它排在最后


# 重命名文件
for idx, file in enumerate(image_files, start=1):
    old_path = os.path.join(destination_folder, file)
    new_name = f"{idx}.png"
    new_path = os.path.join(destination_folder, new_name)

    # 如果文件名不同，才进行重命名
    if old_path != new_path:
        os.rename(old_path, new_path)
        print(f"Renamed: {file} -> {new_name}")
    else:
        print(f"Skipped renaming {file} as it is already correct.")
