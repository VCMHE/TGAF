import sys
import os
sys.path.append(os.getcwd())
import numpy as np
import torch
import torch.nn as nn
from utils.img_read_save import img_save
import warnings
warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
from torch.utils.data import DataLoader
import argparse
from net.SegM import Net
import time
from tqdm import tqdm

task_name = 'VIF'
dataset_name = 'MSRS'

from utils.H5_read import H5ImageTextDataset
# testloader = DataLoader(H5ImageTextDataset(os.path.join('VLFDataset_h5', dataset_name+'_test.h5')), batch_size=1, shuffle=True,
#                         num_workers=0)
testloader = DataLoader(H5ImageTextDataset(os.path.join('VLFDataset_h5', dataset_name+'_test.h5')), batch_size=1, shuffle=True,
                        num_workers=0)


#ckpt_path = os.path.join("models", task_name+'.pth')
# ckpt_path = "./check/ckpt_12.pth"#23,26,29
ckpt_path = "./ckpt_20.pth"#23,26,29
# ckpt_path = "./exp/25_02_01_17_33_epochs_50_lr_0.001_stepsize_10_bs_1_gradweight_10_gamma_0.6/25_02_01_17_33/model/ckpt_10.pth"
# ckpt_path ="./exp/24_10_29_15_20_epochs_150_lr_1e-05_stepsize_50_bs_4_gradweight_20_gamma_0.6/24_10_29_15_20/model/ckpt_30.pth"
save_path = os.path.join("test_output", dataset_name, "T")
os.makedirs(save_path, exist_ok=True)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model = torch.nn.DataParallel(Net())
total_params = sum(p.numel() for p in model.parameters())
print(f"Total parameters: {total_params}")  # 输出：128 * 256 + 256 + 256 * 10 + 10 = 33792 + 2666 = 36458
# model = Net()
model.to(device)
#model = Net().to(device)
#model = nn.DataParallel(model)

pbar = tqdm(total=len(testloader))

model.load_state_dict(torch.load(ckpt_path)['model'])
# model.load_state_dict(torch.load(ckpt_path)['model'])
# state_dict = torch.load(ckpt_path, map_location=device)['model']
# new_state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
# model.load_state_dict(new_state_dict)
model.eval()
with torch.no_grad():
    for i, (data_IR, data_VIS, textA,textB, index) in tqdm(enumerate(testloader)):
        textA = textA.squeeze(1).to(device)
        textB = textB.squeeze(1).to(device)
        data_IR = torch.FloatTensor(data_IR)
        data_VIS = torch.FloatTensor(data_VIS)
        data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
        data_Fuse = model(data_IR, data_VIS, textA,textB)[0]
        data_Fuse = (data_Fuse - torch.min(data_Fuse)) / (torch.max(data_Fuse) - torch.min(data_Fuse))
        fi = np.squeeze((data_Fuse * 255).detach().cpu().numpy())
        fi = fi.astype('uint8')
        img_save(fi, index[0], save_path)
