import torch
from torch.utils.data import Dataset
import h5py

# class H5ImageTextDataset(Dataset):
#     def __init__(self, h5_file_path):
#         self.h5_file_path = h5_file_path
#
#     def __len__(self):
#         with h5py.File(self.h5_file_path, 'r') as h5_file:
#             return len(h5_file['imageA'])
#
#     def __getitem__(self, idx):
#         with h5py.File(self.h5_file_path, 'r') as h5_file:
#             group_names = list(h5_file.keys())
#             sample_name = list(h5_file[group_names[0]].keys())[idx]
#             imageA = torch.from_numpy(h5_file['imageA'][sample_name][()])
#             imageB = torch.from_numpy(h5_file['imageB'][sample_name][()])
#             textA = torch.from_numpy(h5_file['textA'][sample_name][()])
#             textB = torch.from_numpy(h5_file['textB'][sample_name][()])
#             print(textA.shape)
#             print(textB.shape)
#             return imageA, imageB, textA, textB, sample_name
import h5py
import torch
import torch.nn.functional as F

class H5ImageTextDataset(torch.utils.data.Dataset):
    def __init__(self, h5_file_path):
        self.h5_file_path = h5_file_path

    def __len__(self):
        with h5py.File(self.h5_file_path, 'r') as h5_file:
            return len(h5_file['imageA'])

    def __getitem__(self, idx):
        with h5py.File(self.h5_file_path, 'r') as h5_file:
            group_names = list(h5_file.keys())
            sample_name = list(h5_file[group_names[0]].keys())[idx]
            imageA = torch.from_numpy(h5_file['imageA'][sample_name][()])
            imageB = torch.from_numpy(h5_file['imageB'][sample_name][()])
            textA = torch.from_numpy(h5_file['textA'][sample_name][()])
            textB = torch.from_numpy(h5_file['textB'][sample_name][()])

            # 调整 textA 和 textB 的形状为 [1, 70, 768]
            textA = self.resize_tensor(textA, target_shape=(1, 70, 768))
            textB = self.resize_tensor(textB, target_shape=(1, 70, 768))
            # print(textA.shape)
            # print(textB.shape)
            return imageA, imageB, textA, textB, sample_name

    def resize_tensor(self, tensor, target_shape):
        """
        将 tensor 调整为目标形状 [1, B, 768]，其中 B = target_shape[1]。
        如果 tensor 的长度小于目标长度，则填充零；如果大于目标长度，则裁剪。
        同时确保第三维度的大小始终为768。
        """
        # 确保 tensor 是 [1, B, 768] 的形状
        if len(tensor.shape) == 2:
            tensor = tensor.unsqueeze(0)  # 添加一个批次维度
        elif len(tensor.shape) == 3 and tensor.shape[0] != 1:
            tensor = tensor.unsqueeze(0)  # 确保批次维度为 1

        # 如果第三维度的大小不是768，需要进行调整
        if tensor.shape[2] != 768:
            tensor = tensor[:, :, :768]  # 裁剪多余的部分
            if tensor.shape[2] < 768:
                pad_size = (0, 768 - tensor.shape[2], 0, 0, 0, 0)  # 在第三维度填充零
                tensor = F.pad(tensor, pad_size, mode='constant', value=0)

        # 获取当前长度
        current_length = tensor.shape[1]
        target_length = target_shape[1]

        if current_length < target_length:
            # 如果当前长度小于目标长度，填充零
            pad_size = (0, 0, 0, target_length - current_length)
            tensor = F.pad(tensor, pad_size, mode='constant', value=0)
        elif current_length > target_length:
            # 如果当前长度大于目标长度，裁剪
            tensor = tensor[:, :target_length, :]

        return tensor